servers = {
    backup : function () {
        return "http://218.77.105.241:30080/mes/"
    },
    // backup : function() {
    //     return "http://localhost:8082/mes/"
    // },
    // backup : function() {
    //     return "http://115.157.192.47:8080/mes/"
    // },
    // backup : function() {
    //     return 'http://192.168.100.181:8080/mes/'
    // }
//    show global VARIABLES like '%max_allowed_packet%';
//     set global max_allowed_packet = 2*1024*1024*10
}